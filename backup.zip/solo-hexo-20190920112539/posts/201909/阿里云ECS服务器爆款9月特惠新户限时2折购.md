title: 【阿里云ECS服务器爆款9月特惠】新户限时2折购
date: '2019-09-20 10:47:04'
updated: '2019-09-20 10:47:28'
tags: [阿里云]
permalink: /articles/2019/09/20/1568947624810.html
---
【阿里云ECS服务器爆款9月特惠】新户限时2折购：

突发性能型t5： 1核1G1M40G盘，￥538元/3年，

通用网络增强型：2核8G5M40G盘，￥3000元/3年，

计算网络增强型：4核8G5M40G盘，￥3372元/2年

计算网络增强型：8核16G2M40G盘，￥5000元/2年。

计算网络增强型：8核16G8M40G盘，￥10000元/3年。

通用网络增强型：8核32G10M40G盘，￥10000元/2年。

[https://www.aliyun.com/acts/limit-buy?userCode=f46ljm1a](https://www.aliyun.com/acts/limit-buy?userCode=f46ljm1a)
